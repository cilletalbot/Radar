# Radar

Dette projekt er en hjemmeside for Radar, en musik- og kulturplatform. Siden præsenterer information om events, vision, støtte, og tilbyder en donation funktionalitet samt et galleri.


Websitet har forskellige funktioner:

Eventdetaljer: Præsenterer kommende events med detaljer som tid, sted og beskrivelse.
Vision: En sektion, der beskriver Radar Aarhus' vision og mål for fremtiden.
Støtte-sektion: Muligheder for at brugerne kan støtte Radar via donationer og medlemskaber.
Galleri: Et billedegalleri, hvor brugerne kan se billeder relateret til Radar Aarhus’ events og aktiviteter.
Responsiv Design: Designet er optimeret til både desktop og mobile enheder (herunder iPhone 12).